﻿using UnityEngine;

namespace FishNet.Example.ColliderRollbacks
{

    /// <summary>
    /// DEMO. CODE IS NOT OPTIMIZED.
    /// Doesn't do much...
    /// </summary>
    public class PlayerCamera : MonoBehaviour
    {
        /// <summary>
        /// MuzzleFlash on the weapon.
        /// </summary>
        public Transform MuzzleFlash;

    }

}
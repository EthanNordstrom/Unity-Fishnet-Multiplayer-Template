﻿using FishNet.Component.ColliderRollback;
using FishNet.Managing.Timing;
using FishNet.Object;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;


namespace FishNet.Example.ColliderRollbacks
{

    /// <summary>
    /// DEMO. CODE IS NOT OPTIMIZED.
    /// Fires at objects.
    /// </summary>
    public class Fire : NetworkBehaviour
    {
        

    }
}


All settings must be done prior to pressing play.

To configure spawn count:
    - Open NetworkTransform Benchmark scene.
    - Select Prefab Spawner, and set amount.
    
To configure tick rate:
    - Open NetworkTransform Benchmark scene.
    - Select NetworkManager, change Tick Rate on TimeManager.

To configure object rates and movement:
    - Open prefab NetworkTransform Benchmark.
    - Configure MoveRandomly.    
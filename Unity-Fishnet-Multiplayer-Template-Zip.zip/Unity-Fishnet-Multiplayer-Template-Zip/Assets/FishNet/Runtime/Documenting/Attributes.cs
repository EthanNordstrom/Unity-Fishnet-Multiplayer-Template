﻿
using System;

namespace FishNet.Documenting
{
    public class APIExcludeAttribute : Attribute { }

}

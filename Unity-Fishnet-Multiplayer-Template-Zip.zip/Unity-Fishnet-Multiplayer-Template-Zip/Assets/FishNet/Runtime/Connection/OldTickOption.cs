﻿using System.Runtime.CompilerServices;

namespace FishNet.Managing.Timing
{


}
namespace FishNet.CodeGenerating.Helping
{

    internal enum QolAttributeType
    {
        None,
        Server,
        Client
    }


}